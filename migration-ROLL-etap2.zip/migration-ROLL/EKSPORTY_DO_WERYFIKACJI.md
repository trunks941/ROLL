# Materiały potrzebne do weryfikacji migracji

Dotyczy projektu `04201`, STEP 5 / COMTEXT → S7-1513-1 PN / TP900 Comfort, TIA V19.

Archiwa S5 i OP15 są już zachowane i zinwentaryzowane. Użytkownik potwierdził ich zgodność z maszyną oraz dostęp do STEP 5 i COMTEXT. Nie trzeba przesyłać tych samych ZIP-ów ponownie.

## Pierwsza partia: weryfikacja odczytu instrukcji

Otwórz kopię offline `04201@ST.S5D` w STEP 5 i przygotuj listing w języku AWL dla:

| Blok | Cel porównania |
|---|---|
| OB1 | Kolejność wywołań i warunek pierwszej inicjalizacji |
| OB13 | Dzielenie taktów i zachowanie zegarów |
| OB21 i OB22 | Uruchomienie po STOP / zaniku zasilania |
| FB61 | Okres OB13, ustawienia systemowe i retencja |
| FB105 | Tworzenie DB, kopiowanie wartości domyślnych i ustawienie stanu inicjalizacji |
| FB101 | Przekazywanie nastaw czasów/liczników z panelu |

Wydruk powinien zawierać **pełne instrukcje, numery sieci, operandy absolutne oraz komentarze**, a przy wywołaniach FB także parametry. Symbole mogą występować dodatkowo. Preferowany jest plik tekstowy; czytelny PDF również wystarczy. Nazwa rozszerzenia pliku nie jest istotna — potrzebna jest treść listingu, nie kolejna kopia pliku binarnego S5D.

Jeśli wybrane narzędzie pozwala wydrukować wszystkie bloki jednym poleceniem, pełna dokumentacja AWL całego projektu będzie jeszcze przydatniejsza. Na początek wystarczy powyższy zestaw, aby porównać odczyt binarny z narzędziem STEP 5. W następnej partii będą potrzebne bloki panelu FB3/FB51/FB60/FB89/FB90/FB91/FB92/FB95/FB96 oraz pełne listingi logiki procesu przed zatwierdzeniem konwersji.

W FB105 należy szczególnie zachować oryginalny zapis instrukcji zaczynających się w kodzie binarnym od `78 05`: odczytywana tabela zewnętrzna ma tu niejednoznaczność oznaczenia DB/DX. Listing STEP 5 pozwoli ją rozstrzygnąć bez zgadywania.

## COMTEXT: adresy i zachowanie panelu

Otwórz `04201.O15`. Przygotuj dokumentację projektu, która pokazuje:

- połączenie ze sterownikiem i ustawione obszary wymiany danych;
- listę aktywnych ekranów oraz numery/nazwy ekranów;
- każde pole ze wskazaniem DB/obszaru, numeru słowa lub bitu, formatu, kierunku odczyt/zapis, limitów i jednostki;
- przypisania klawiszy funkcyjnych oraz funkcje wywoływane przy ich obsłudze;
- alarmy z numerami, tekstami i powiązaniem z PLC, wraz ze sposobem potwierdzania;
- strukturę receptury/programu, kolejność pól i mechanizm przesyłania/potwierdzania;
- używane funkcje systemowe i ewentualne drukowanie danych.

Najważniejsza jest dokumentacja aktywnych wpisów projektu. Surowy plik O15 zawiera powtórzone fragmenty tekstów, dlatego sama lista odnalezionych napisów nie wystarcza do ustalenia ekranów i adresów. Nie dołączaj haseł.

Nazwy menu dokumentacji/drukowania zależą od wersji i języka STEP 5 oraz COMTEXT. Jeśli nie możesz znaleźć sposobu zapisu wydruku, prześlij obraz menu dokumentacji lub drukowania — wtedy instrukcję można dopasować do rzeczywiście dostępnych opcji.

## Dane robocze i receptury

DB15 i DB19 są opisane w symbolach, ale ich treści nie ma w katalogu przesłanego pliku. Odczyt FB105 ma ustalić, jak są tworzone i inicjalizowane. Do zachowania aktualnych nastaw potrzebny będzie istniejący zapis ich aktualnych wartości lub odczyt wykonany z działającego układu przez osobę mającą do niego dostęp.

Potrzebny jest też komplet używanych receptur/programów operatora. Projektowanie ekranów i formatów receptur nie dowodzi, że archiwum projektu zawiera wszystkie aktualne zestawy wartości.

W DB12 i DB16 występują wartości `FFFF` i słowa przy końcu bloków. Nie traktować ich automatycznie jako nastaw czasu lub licznika. Ich rolę trzeba ustalić przez kod i dokumentację pól.

## Sprzęt i oprogramowanie

Użytkownik ma schemat elektryczny i oznaczenia modułów. Należy dołączyć schemat oraz listę lub zdjęcia czytelnych oznaczeń starego CPU, modułów I/O i modułów komunikacyjnych, z ich pozycjami w kasetach. Na tej podstawie powstanie lista docelowych modułów, adresów i połączeń; sama tabela symboli nie jest listą zakupową.

CPU `6ES7513-1AM03-0AB0` jest zamówiony. Wersja firmware zostanie sprawdzona po dostawie; jej brak obecnie nie blokuje analizy źródeł. Użytkownik podał pakiet „Advanced”, interpretowany jako WinCC Advanced w TIA V19. Ten pakiet obsługuje panele Comfort; dostępność STEP 7 Professional, zakres licencji i katalog urządzeń należy potwierdzić przy budowaniu projektu TIA.

Materiały mogą być przesyłane partiami: najpierw listingi STEP 5 i schemat, następnie dokumentacja COMTEXT oraz wartości robocze.

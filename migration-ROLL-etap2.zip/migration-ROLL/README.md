# ROLL KS04201 — materiały migracji

Zacznij od [ustaleń etapu 2](USTALENIA_ETAP2.md) i [listy eksportów](EKSPORTY_DO_WERYFIKACJI.md).

Oryginalne pliki S5 i COMTEXT są w `originals/`. Ich sumy SHA-256 są zapisane w `analysis/inventory.json`. Program i panel nie zostały zmienione; nie powstał jeszcze projekt TIA do kompilacji/wgrania.

Mapa początkowa: [MAPA_MIGRACJI.md](MAPA_MIGRACJI.md). Dokładny przegląd danych panelu: [data_review/PRZEGLAD_DANYCH_HMI.md](data_review/PRZEGLAD_DANYCH_HMI.md). Ograniczenia czytnika i jego kontrola: [offline_decoder/README.md](offline_decoder/README.md).

Zestawienia można odtworzyć standardowym Pythonem 3, po rozpakowaniu całego katalogu. W podanej kolejności:

```sh
python analyse_archives.py
python offline_decoder/decode_mc5.py
python offline_decoder/test_decoder.py
python data_review/review_data.py
```

Polecenia odczytują kopie offline i zapisują zestawienia obok nich. Nie wykonują połączenia ze sterownikiem ani panelem. Kontrole czytnika nie są testami zachowania maszyny. CSV używają UTF-8 z BOM i separatora średnik.

`analysis-stage2/io-timer-counter-references.csv` jest dodatkowym zestawieniem statycznych odwołań z aktualnego `offline_decoder/instructions.csv`; nie jest konfiguracją sprzętu ani listą zakupową.

Źródła i licencja pomocniczego czytnika MC5: `offline_decoder/NOTICE.md`, `offline_decoder/LICENSE-LGPL-2.1.txt` i `offline_decoder/reference/`. Oryginalny program użytkownika nie otrzymuje przez to nowej licencji.

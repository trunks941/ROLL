# ROLL KS04201 — analiza instrukcji i danych, etap 2

Wznowienie: 9 października 2026. Materiał źródłowy jest zachowany bez zmian; SHA-256 wszystkich plików oryginalnych zgadza się z poprzednią inwentaryzacją. Użytkownik potwierdził zgodność kopii z maszyną, dostęp do STEP 5 i COMTEXT, posiadanie schematu i oznaczeń modułów. CPU jest zamówiony; firmware poznamy po dostawie. Podany pakiet „Advanced” przyjęto jako WinCC Advanced V19; STEP 7 Professional i docelową konfigurację urządzeń trzeba jeszcze potwierdzić.

## Co przygotowano

- Robocze listingi MC5/AWL dla bloków z bieżącego katalogu S5D, z pozycjami, surowymi bajtami i opisami symboli, w `offline_decoder/listings/`.
- Wykaz statycznych wywołań, otwarć bloków danych, instrukcji tworzenia i odwołań pośrednich. Listingi służą analizie, a nie importowi do TIA.
- Odczyt deklarowanych formatów danych z nagłówków DV i zestawienia surowych wartości domyślnych w `data_review/`.
- Zestawienie odwołań do I/O, timerów i liczników w `analysis-stage2/io-timer-counter-references.csv`.
- [Dokładny zakres eksportów STEP 5 / COMTEXT](EKSPORTY_DO_WERYFIKACJI.md), potrzebnych do porównania oraz dalszej migracji.

44 zwykłe bloki OB/PB/FB obejmują 18 252 bajty ciał instrukcji; czytnik przypisał wszystkie te bajty do rozpoznanych instrukcji i danych wywołań. Pozostałych 5 bloków ma flagę assemblera i zachowano je jako surowe dane: OB31, FB240–FB243. Ich ciała po deklaracjach FB obejmują 30 bajtów. Odczyt zawiera 51 statycznych wywołań i 178 skoków. To pokrycie bajtów i kontrola struktury, nie potwierdzenie semantycznej równoważności przez STEP 5.

Przeszło 16 kontroli czytnika, obejmujących długości instrukcji ze stałymi, maski I/O, formaty KT/KZ, deklaracje i argumenty FB, ujemne skoki oraz zachowanie nieznanego kodu. Dodatkowo sprawdzono osiem wywołań FB96 w dostarczonym programie i wszystkie granice jego skoków. Kontrole nie uruchamiają logiki maszyny.

## Uruchomienie i inicjalizacja

OB1 zaczyna od `UN M0.4` i warunkowego wywołania FB105. M0.4 jest w symbolach opisany jako stała logiczna 1. Dopóki nie jest ustawiony, OB1 może zakończyć się przed logiką procesu. FB105 używa etapów w M240.x, a przy końcu ustawia M0.4 i zeruje M0.3. To wskazuje na inicjalizację rozłożoną na kolejne obiegi, którą trzeba odróżnić od zwykłego ponownego uruchomienia CPU.

W odczycie FB105:

- przed instrukcjami tworzenia obszarów 15/19 ładowana jest długość 131;
- MW242 otrzymuje 128, jest zmniejszany o 1 i służy jako indeks przy kopiowaniu DW z DB12 → DB15 oraz DB16 → DB19;
- pętla kopiowania obejmuje indeksy 127…0, a nie cały archiwalny blok z końcowymi polami;
- dalsze obszary tworzenia mają numery 41, 51, 205, 210, 211, 60 i 213, z dodatkowymi ustawieniami komunikacji;
- blok wywołuje OB31 podczas inicjalizacji.

Mnemonik instrukcji `78 05` wymaga potwierdzenia w STEP 5: użyta tabela zewnętrzna pokazuje `E DX`, podczas gdy następujące odwołania i komentarze wskazują DB. Nie zmieniono etykiety bez dowodu. Propozycja dla S7 to jawne, statycznie zadeklarowane DB oraz odtworzona inicjalizacja z ustalonymi regułami retencji; dokładne zachowanie zależy od porównania listingu i danych online.

OB21 i OB22 mają identyczne ciała instrukcji: wywołują FB61, ustawiają znaczniki restartu M0.1/M0.2 oraz M191.0 dotyczący startu panelu. Nie należy zastępować tych działań ogólnym wyzerowaniem pamięci. Na poziomie docelowego projektu trzeba rozdzielić stan inicjalizacji, dane operatora, stany sekwencji i sygnały restartu.

## Takty i ustawienia CPU

FB61 zapisuje 25 do BS97, ustawia bit maski `0008` w BS120 i zapisuje 1000 do BS126. Komentarze mówią odpowiednio o wywołaniu OB13 co 0,25 s, retencji wszystkich znaczników i opóźnieniu startu 1 s. Znaczenie konkretnych BS wymaga instrukcji dla faktycznego CPU S5; numery tych obszarów nie przechodzą do programu S7.

OB13 ma wzorzec: odwróć M3.4, zakończ warunkowo; następnie tak samo M3.5 i M3.6, a na końcu odwróć M3.7. Jest to dzielnik taktów. **Przy założeniu potwierdzonego wywołania co 250 ms**:

| Bit | Czas pomiędzy zmianami stanu | Pełny okres sygnału |
|---|---:|---:|
| M3.4 | 250 ms | 500 ms |
| M3.5 | 500 ms | 1 s |
| M3.6 | 1 s | 2 s |
| M3.7 | 2 s | 4 s |

Nazwy symboli opisują takty, a nie jednoznacznie pełny okres. W S7 trzeba zachować wykorzystywane zbocza, fazę oraz stan po restarcie; błędne przyjęcie nazw jako okresów może podwoić lub skrócić czas działania.

## Nastawy czasu i liczników

Nagłówek DV12 opisuje regiony KT/KH, a DV16 deklaruje słowa KH. Deklarowany format wyświetlania nie przesądza o interpretacji podczas wykonania instrukcji. W DB12 jest 131 słów, w tym 99 `FFFF`. W DB16 jest 132 słowa, w tym 126 `FFFF`. Nie należy zamieniać `FFFF` na zwykłą nastawę liczbową.

FB101 otwiera osobno DB15 i DB19. W obu korzysta z:

| Pole źródłowe | Znaczenie wynikające z odczytanego przepływu |
|---|---|
| DW0…DW127 | Indeksowane wartości parametrów |
| DW128 | Wybrany numer parametru |
| DW129 | Zapamiętany poprzedni wybór |
| DW130 | Bufor wartości pokazywanej/edytowanej |

Blok pomija wpisy `FFFF`, wykrywa zmianę wyboru i wtedy ładuje bufor; przy tym samym wyborze przenosi bufor do indeksowanej wartości. Zatem DW128–130 w roboczych DB nie są trzema kolejnymi nastawami procesu. Odczyt wskazuje również różnicę między ścieżkami korekty indeksu czasu i licznika; wymagają porównania z listingiem natywnym.

Przy tłumaczeniu porównań należy zachować starą notację S5: `!=F` oznacza porównanie równości, natomiast `><F` nierówność. Znaków `!=` nie można interpretować tak jak operatora nierówności w nowoczesnych językach.

## Receptura i program czyszczenia

FB89 i FB90 pozwalają rozpoznać część struktury DB205. Weryfikację pełnej kolejności pól i ograniczeń trzeba oprzeć także na COMTEXT.

| Dane źródłowe | Funkcja w odczycie kodu |
|---|---|
| Starszy bajt DW0 | Sprawdzenie identyfikatora receptury równego 1 |
| Młodszy bajt DW0 | Numer zestawu danych sprawdzany w zakresie 1…99 |
| DW5, DW17, DW25, DW33 | Czasy przebywania w stacjach 1…4; część wyboru stacji w FB90 i nastaw T1 w FB111 |
| DW9, DW21, DW29 | Czasy ociekania stacji 1…3 przekazywane do T2 |
| DW13 | Porównanie z 1 włącza ultradźwięki stacji 1 |
| DW37 | Tryb ruchu: 1 obrót, 2 kołysanie, 3 obrót interwałowy, 4 obrót/kołysanie |
| DW41 | Porównanie z 1 włącza funkcję opisaną jako BADHUB |

Kod FB89 wymaga zestawu danych 1…99, więc nie należy ograniczać programu wyłącznie według starego komentarza mówiącego o 10 zestawach. Nie jest to dowód, że wszystkie 99 zestawów zapisano w panelu.

Transfer ma stany rozpoczęcia, zakończenia, potwierdzenia i błędu, a także kontrolę czasu. Docelowy interfejs TP900 powinien odtwarzać wynikowe funkcje, zamiast przenosić stare słowa protokołu bez opisania ich znaczenia. Stanowisko HMI, aktualna receptura i bufor nowej receptury powinny być rozdzielone, z przełączeniem po zakończeniu i walidacji transferu. To propozycja projektu do sprawdzenia wobec obecnego sposobu obsługi.

FB60 przygotowuje w DB213 żądanie: DW1 otrzymuje `KY 0,70`, DW2 liczbę 1, DW3 wybrany numer programu. DB51.DW60/61 wskazują na DB213 i jego DW1. W tym przepływie PLC przygotowuje żądanie do panelu; wcześniejszy opis DB213 wyłącznie jako zleceń OP15 → PLC, oparty na komentarzu symbolu, został skorygowany. Kod polecenia 70 i funkcję jego parametrów trzeba porównać z dokumentacją COMTEXT/protokołu.

**Zapisane słowa DB205 nie potwierdzają poprawnej aktualnej receptury.** W archiwalnym buforze DW13=`2020`, DW37=`2150`, DW41=`0002`, podczas gdy odczytane warunki używają odpowiednio wartości 1, trybów 1…4 i wartości 1. Tych słów nie należy automatycznie uznać za aktualny program operatora ani przeliczać wszystkich jako czasy. Potrzebne są aktywne zestawy danych OP15 i ich definicja z COMTEXT. Zgodność programu z maszyną, potwierdzona przez użytkownika, nie rozstrzyga interpretacji każdej archiwalnej zawartości bufora.

Obsługa ręczna zawiera także warunki reagujące na utrzymany stan klawisza, m.in. powiązania M190.6 z poleceniami w PB16. Dlatego przy zamianie klawiatury OP15 na ekran dotykowy nie można jednolicie zamienić wszystkich przycisków na krótkie impulsy. Dla każdego ruchu trzeba ustalić funkcję klawisza, zezwolenia, czas utrzymania polecenia i zachowanie po utracie łączności.

## I/O i ograniczenia odczytu

W statycznych odwołaniach odczytanych zwykłych bloków występuje 97 różnych bitów E, 63 bity A, 75 timerów i 3 liczniki. Wszystkie mają symbole. E6.6 — opisany jako minimum zbiornika wody VE — nie ma bezpośredniego odwołania w tych listingach. Nie wynika z tego, że kanał jest fizycznie zbędny: znaczenie trzeba potwierdzić w schemacie i weryfikacji programu.

FB0 i FB240–FB243 nie mają znalezionych statycznych wywołań w zwykłych listingach. Pozostają w inwentaryzacji; nie usunięto ich ani nie uznano za na pewno nieużywane.

Dwa konkretne ograniczenia:

1. W FB51 skok z pozycji `0x0416` wskazuje `0x041A`, czyli słowo rozpoznawane jako BE, które jest jednocześnie częścią argumentu poprzedniej instrukcji w liniowym odczycie. Zachowano obie interpretacje. To miejsce do sprawdzenia w natywnym narzędziu; sama nietypowa struktura nie dowodzi błędu działającego programu.
2. Dziewięć instrukcji tworzenia w FB105 ma niepotwierdzoną etykietę DB/DX. Typ docelowych danych trzeba ustalić przed konwersją.

Kontrole parsera nie zastępują kompilacji, porównania STEP 5 ani testów maszyny. O15 nadal nie został odkodowany jako pełny aktywny projekt HMI; dokumentacja COMTEXT jest potrzebna dla pól, klawiszy i receptur. Dostęp do oficjalnej witryny wsparcia Siemensa był blokowany przez proxy (403), więc znaczenia obszarów systemowych i zgodności firmware nie potwierdzono przez pobrane instrukcje producenta.

## Następny krok

Przekazać pierwszą partię listingów wymienionych w [instrukcji eksportów](EKSPORTY_DO_WERYFIKACJI.md) i schemat z oznaczeniami modułów. Umożliwi to porównanie odczytu, rozstrzygnięcie tworzenia DB, określenie retencji oraz dobór rzeczywistego sprzętu I/O. Równolegle potrzebna jest dokumentacja aktywnych pól i klawiszy COMTEXT; aktualne DB15/DB19 i receptury będą podstawą przeniesienia nastaw operatora.

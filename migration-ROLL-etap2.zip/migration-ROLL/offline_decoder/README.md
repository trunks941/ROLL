# Eksploracyjny odczyt MC5 z bieżącego katalogu S5D

Ten katalog zawiera **listing do analizy**, nie program S7 i nie projekt TIA.
Nie wykonuje połączenia ze sterownikiem, nie wysyła instrukcji i nie zapisuje
oryginalnych archiwów. Odczyt MC5 nie został jeszcze porównany z natywnym
listingiem STEP 5. Użytkownik potwierdził zgodność archiwum z maszyną; w tym
środowisku nie było porównania online.

## Odtworzenie i sprawdzenie

Wymagany jest wyłącznie Python 3 ze standardową biblioteką:

```sh
python /workspace/migration-ROLL/offline_decoder/decode_mc5.py
python /workspace/migration-ROLL/offline_decoder/test_decoder.py
```

Skrypt bierze numery, długości i przesunięcia **bieżących** bloków z
`../analysis/s5-program-blocks.csv`. Sprawdza SHA-256 każdej treści przed
odczytem. Nie szuka bloków w pozostałościach starszych wersji pliku. Zapisuje
wyłącznie nowe zestawienia i listingi w tym katalogu.

Wynik 2026-10-09: **16 testów przeszło**. Testy obejmują niezależne małe
próbki 4- i 6-bajtowych instrukcji ze stałą, KT/KZ z BCD i bazą czasu, maski
wejść/wyjść, deklaracje FB, argumenty wywołań, błędną liczbę argumentów,
ujemne skoki liczone od własnego adresu, skok w środek stałej oraz nieznany
kod. Dodatkowo sprawdzono osiem rzeczywistych wywołań FB96 z FB92 i jedyny
znany przypadek nakładania instrukcji. To kontrola czytnika i struktury,
**nie test zachowania maszyny**.

## Zakres i wyniki

| Sprawdzenie | Wynik |
|---|---:|
| Bloki OB/PB/FB w bieżącym katalogu | 49 |
| Bloki bez flagi assemblera z listingiem instrukcji | 44 |
| Bajty ich treści instrukcji, włącznie z opisami wywołań | 18 252 |
| Bajty zachowane jako nieznany kod w tych 44 blokach | 0 |
| Bloki z flagą assemblera, zachowane jako surowe dane | 5 |
| Surowe bajty ich treści po nagłówku/deklaracjach | 30 |
| Wiersze instrukcji listingu liniowego | 8 821 |
| Bezpośrednie wywołania zapisane w kodzie | 51 |
| Otwarcia DB zapisane w kodzie | 49 |
| Kandydaci instrukcji tworzenia DB/DX | 9 |
| Skoki względne / wsteczne | 178 / 6 |
| Cele skoków na granicy instrukcji liniowej | 177 / 178 |

Zero nieznanych kodów oznacza dopasowanie do tabeli porównawczej i zużycie
całych bajtów, a nie dowód poprawnej semantyki. Warunki wywołań, akumulatory,
VKE/RLO, flagi, timery, pośrednie adresowanie oraz stan DB nie są symulowane.

Wszystkie 51 celów bezpośrednich wywołań ma wpis w dostarczonym katalogu.
Jedynymi otwieranymi DB bez bieżącej treści archiwalnej są **DB15 i DB19**.
Zestawienie otwarć obejmuje również stałe bazowe instrukcji modyfikowanych
przez poprzedzające `B`; nie są one dowodem, że rzeczywisty cel pozostaje stały.

## Miejsca wymagające porównania z STEP 5

1. **FB105: opcode `78 05 00 xx`.** Tabela biblioteki nazywa go `E DX`.
   W tym programie numery zgadzają się z otwieranymi DB, nie ma bloków DX,
   komentarze mówią o tworzeniu DB. Listing celowo zachowuje etykietę `DX`
   oraz flagę `OPCODE_7805_DB_DX_LABEL_UNVERIFIED`. Nie poprawiono jej na
   `DB` bez niezależnego potwierdzenia. Do porównania: offsety FB105
   `003A,008C,00DC,00E6,00FA,0108,0112,0120,012A`.
2. **FB51, końcówka bloku.** `2D02` pod `0416` prowadzi do `041A`, gdzie
   surowe `6500` można odczytać jako `BE`. Listing liniowy pod `0418`
   odczytuje `30406500` jako `L KH 6500`; cel jest wewnątrz tej stałej.
   Zachowano oba odczyty i ostrzeżenie. Nie ustalono, czy to zamierzona
   technika bloku standardowego, czy specjalna reprezentacja wymagająca
   natywnego narzędzia. Nie wolno ignorować tej rozbieżności.
3. **OB31 i FB240–FB243:** ustawiona flaga assemblera. Nie deklarowano
   zgodności ich treści z AWL. FB240–243 mają rozpoznane deklaracje parametrów,
   ale treść `7808 0000 6500` pozostaje surowa. `7808` nie ma w tabeli.
4. **18 instrukcji `B`:** ich działanie modyfikuje następny operand. Surowe
   `L DW0`, `T DW0` albo `A DB0` po nich nie oznacza stałego rzeczywistego
   adresu. Odtworzenie wymaga semantyki CPU i bieżącego akumulatora.
5. **Legacy porównania:** Siemens S5 `!=F` oznacza równość, `><F`
   nierówność. Nie tłumaczyć `!=F` według znaczenia `!=` w Pythonie/C.
6. **Parametry czasu:** `KT xxx.b` odczytano jako trzy cyfry BCD i numer
   bazy czasu (0:10 ms, 1:100 ms, 2:1 s, 3:10 s). Zachować surowe słowo i
   porównać z STEP 5. Domyślne wartości DB nie są bieżącymi nastawami maszyny.

## Co wnosi odczyt priorytetowych bloków

- **FB105** ma stany M240.x oraz indeks MW242. Dla czasów kopiuje DB12
  do DB15, a dla liczników DB16 do DB19, przez operand modyfikowany `B MW242`.
  Indeks startuje od 128, następnie jest zmniejszany; widoczny zakres kopii
  to DW127…DW0. `!=F` z zerem ustawia stan zakończenia. Kopia odbywa się
  etapami z powrotami `BEA`/`BEB`, nie jako jeden ciąg instrukcji w jednym
  wywołaniu. Opis `E DX` jest nierozstrzygnięty jak wyżej. Stałe bezpośrednio
  przed kolejnymi kandydatami tworzenia to 131 dla 15/19, 40 dla 41, 186
  dla 51, 220 dla 205, 128 dla 210, 10 dla 211, 50 dla 60 i 10 dla 213.
  Nie przesądzają jeszcze interpretacji długości instrukcji tworzenia.
- **FB61** zapisuje `KF +25` do BS97, wykonuje OR BS120 z `KH 0008`,
  zapisuje `KF +1000` do BS126. Komentarze podają okres OB13 0,25 s,
  retencję wszystkich merkerów i opóźnienie startu 1 s. Przypisanie adresów
  BS do funkcji wymaga dokumentacji konkretnego starego CPU.
- **OB13** odwraca M3.4, następnie warunkowo wychodzi przez BEB; podobnie
  M3.5 i M3.6, na końcu M3.7. Przy wywołaniu co 250 ms jest to dzielnik
  binarny: pełne okresy M3.4/M3.5/M3.6/M3.7 wynoszą odpowiednio
  0,5/1/2/4 s, a czasy między zmianami stanu 0,25/0,5/1/2 s.
  Ustawienia i stan początkowy wymagają potwierdzenia. Nazwy symboli nie
  oznaczają tutaj pełnych okresów.
- **OB21 i OB22** wywołują FB61 i ustawiają bity restartu M0.1/M0.2;
  ustawiają także M191.0 identyfikujący start panelu. Należy zachować
  różnicę między ustawieniem i skasowaniem bitu.
- **FB60** obejmuje etapy zapisane w DB60.DW10 i wymianę z DB51/205/213.
  **FB89** używa DB51.DW64, sprawdza DB205 i wywołuje FB90.
  **FB90** wyprowadza cechy receptury do M110/M111 z wybranych słów DB205.
  Dokładny interfejs danych trzeba zestawić z COMTEXT.
- **FB101** obsługuje pośrednie nastawy w DB15 i DB19: DW128 jako indeks,
  DW129 jako poprzednio wybrany indeks, DW130 jako pole bieżącej wartości.
  Sprawdza słowo `FFFF` i przełącza odczyt/edycję zależnie od zmiany indeksu.
  Nie ma tu podstaw do automatycznego uznania wszystkich wartości za BCD.
- **FB111** pobiera wybrane czasy z DB205 i uruchamia T1/T2; stała
  rezerwowa to `KT 010.2` (10 s), nie liczba binarna 8210. Wybór czasu
  zależy od stanów sekwencji. Listing nie dowodzi obsługi wszystkich
  opcjonalnych stacji.
- **FB92 → FB96:** osiem wywołań ma zgodne deklaracje E/W `INPU`, A/W
  `OUTP` i trzy słowa opisu, włącznie ze skokiem pomijającym argumenty.
  Parametry to MW37,39,…51 → DW50,…57 aktualnie otwartego DB. Nie
  przypisano tych argumentów do DB na podstawie samego adresu DW.
- **FB0** nazwany `INDIREKT` zawiera po nagłówku wyłącznie `BE`. Nazwa
  sama w sobie nie dowodzi, że posiada kod adresowania pośredniego.

## Ograniczenia tabeli źródłowej i korekty czytnika

Źródło porównawcze nie jest autorytatywną specyfikacją Siemensa. Niezależny
przegląd zidentyfikował błędy/niekompletności jego implementacji:

- Odczyt parametrów >32 bitów zwracał zero; tutaj 6-bajtowe instrukcje
  zachowują pełne 32-bitowe dane stałej.
- `PrintTimer` nie miał obsługi, a inline KT używał dziesiętnej wartości
  surowego słowa; tutaj KT/KZ mają jawny odczyt BCD i bazy.
- `TNW` ma `parlen=0` mimo maski parametru: czytnik zachowuje maskę i
  flaguje sprzeczność, zamiast zwracać zero.
- Wpis `L QB` deklaruje 14 bitów: czytnik zaokrągla do całego słowa i
  flaguje wpis, zamiast przesuwać się o jeden bajt.
- `SVW` ma pakowany parametr w bitach 4…7: znormalizowano nibble i dodano
  wymaganie porównania natywnego. Ta instrukcja nie występuje w listingu.
- KC w źródłowej implementacji miał niespójną kolejność/obsługę bajtów;
  tutaj zachowano kolejność pliku z jawnym wymaganiem porównania.
- Warianty obszaru A przy `7038` mają błędną kombinację maski i `code1`.
  Te kody nie występują w interpretowanych blokach tego projektu;
  ogólna poprawność rozszerzonego zestawu instrukcji nie została wykazana.
- KG pozostaje surową stałą z flagą nieobsługiwanej semantyki float;
  ogólne wielosłowowe argumenty wywołań też pozostają nieobsługiwane.

## Pliki

- `listings/*.txt`: 49 listingów/surowych treści z przesunięciem w bloku,
  przesunięciem w S5D, hex, operandem, symbolem i flagami.
- `instructions.csv`: instrukcje z 44 bloków; sieci według markerów BLD255
  są orientacyjne, nie oznaczają potwierdzonego przypisania komentarzy.
- `direct-calls.csv`: zapisane wywołania i warunkowość.
- `db-open-references.csv`: otwarcia DB/DX i obecność w katalogu.
- `create-candidates.csv`: opcode tworzenia, cel numeryczny i poprzednia
  stała; nie jest to potwierdzona konfiguracja DB.
- `fb-parameters.csv`, `call-arguments.csv`: deklaracje FB i argumenty
  opisów wywołań, z niezależnymi offsetami.
- `jump-references.csv`, `jump-target-overlays.csv`: cele skoków i odczyt
  alternatywny w jedynym przypadku nakładania.
- `decoder-issues.csv`: 28 jawnych flag (18 B, 9 kodów tworzenia, 1 skok).
- `block-statistics.csv`, `decoder-statistics.json`: zakres i wyniki.
- `NOTICE.md`, `LICENSE-LGPL-2.1.txt`, `reference/`: źródło i licencja.
